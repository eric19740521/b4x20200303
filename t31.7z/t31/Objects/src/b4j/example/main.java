package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static b4j.example.xyzbutton _xyzbutton1 = null;
public static b4j.example.xyzedittext _xyzedittext1 = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _textfield1 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 19;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 20;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 24;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 32;BA.debugLine="xui.MsgboxAsync(\"Hello World!\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello World!","B4X");
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private xyzButton1 As xyzButton";
_xyzbutton1 = new b4j.example.xyzbutton();
 //BA.debugLineNum = 14;BA.debugLine="Private xyzEditText1 As xyzEditText";
_xyzedittext1 = new b4j.example.xyzedittext();
 //BA.debugLineNum = 15;BA.debugLine="Private TextField1 As TextField";
_textfield1 = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public static String  _textfield1_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Private Sub TextField1_MouseClicked (EventData As";
 //BA.debugLineNum = 53;BA.debugLine="xui.MsgboxAsync(\"SAS\", \"B4X\")";
_xui.MsgboxAsync(ba,"SAS","B4X");
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public static String  _xyzbutton1_click() throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Private Sub xyzButton1_Click";
 //BA.debugLineNum = 36;BA.debugLine="Log(\"xyzButton1_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2196609","xyzButton1_Click==>",0);
 //BA.debugLineNum = 38;BA.debugLine="xui.MsgboxAsync(\"Hello World!\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello World!","B4X");
 //BA.debugLineNum = 40;BA.debugLine="xyzButton1.T1=\"xyz\"";
_xyzbutton1._sett1 /*String*/ ("xyz");
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _xyzedittext1_click() throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Private Sub xyzEditText1_Click";
 //BA.debugLineNum = 46;BA.debugLine="xui.MsgboxAsync(\"Hello World!123\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello World!123","B4X");
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
}
