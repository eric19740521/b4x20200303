package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzbutton extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzbutton", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzbutton.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbase = null;
public int _mleft = 0;
public int _mtop = 0;
public int _mwidth = 0;
public int _mheight = 0;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xparent = null;
public anywheresoftware.b4j.objects.ButtonWrapper _obutton = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _b4xbutton = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public Object _tag = null;
public String _mt1 = "";
public String _mt2 = "";
public b4j.example.main _main = null;
public String  _b4xbase_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 122;BA.debugLine="Private Sub b4xBase_Touch (Action As Int, X As Dou";
 //BA.debugLineNum = 123;BA.debugLine="Log(\"b4xBase_Touch==>\")";
__c.LogImpl("21376257","b4xBase_Touch==>",0);
 //BA.debugLineNum = 124;BA.debugLine="Log( Action)";
__c.LogImpl("21376258",BA.NumberToString(_action),0);
 //BA.debugLineNum = 126;BA.debugLine="If b4xBase.TOUCH_ACTION_UP == Action Then";
if (_b4xbase.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 127;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 128;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 132;BA.debugLine="End Sub";
return "";
}
public String  _b4xbutton_click() throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Private Sub b4xButton_Click";
 //BA.debugLineNum = 145;BA.debugLine="Log(\"b4xButton_Click==>\")";
__c.LogImpl("21900545","b4xButton_Click==>",0);
 //BA.debugLineNum = 146;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 147;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public String  _b4xbutton_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Private Sub b4xButton_Touch (Action As Int, X As D";
 //BA.debugLineNum = 134;BA.debugLine="Log(\"oButton_Touch==>\")";
__c.LogImpl("21703937","oButton_Touch==>",0);
 //BA.debugLineNum = 135;BA.debugLine="Log( Action)";
__c.LogImpl("21703938",BA.NumberToString(_action),0);
 //BA.debugLineNum = 137;BA.debugLine="If b4xButton.TOUCH_ACTION_UP == Action Then";
if (_b4xbutton.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 138;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 139;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return "";
}
public String  _base_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 97;BA.debugLine="Private Sub Base_Resize (Width As Double, Height A";
 //BA.debugLineNum = 98;BA.debugLine="Log(\"Base_Resize==>\")";
__c.LogImpl("2458753","Base_Resize==>",0);
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public String  _base_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Private Sub Base_Touch (Action As Int, X As Double";
 //BA.debugLineNum = 105;BA.debugLine="Log(\"Base_Touch==>\")";
__c.LogImpl("2524289","Base_Touch==>",0);
 //BA.debugLineNum = 106;BA.debugLine="Log( Action)";
__c.LogImpl("2524290",BA.NumberToString(_action),0);
 //BA.debugLineNum = 108;BA.debugLine="If b4xBase.TOUCH_ACTION_UP == Action Then";
if (_b4xbase.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 109;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 110;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 18;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 19;BA.debugLine="Public b4xBase As B4XView";
_b4xbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private mLeft, mTop, mWidth, mHeight As Int";
_mleft = 0;
_mtop = 0;
_mwidth = 0;
_mheight = 0;
 //BA.debugLineNum = 23;BA.debugLine="Private b4xParent As B4XView";
_b4xparent = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private oButton As Button";
_obutton = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private b4xButton As B4XView";
_b4xbutton = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 30;BA.debugLine="Public Tag As Object";
_tag = new Object();
 //BA.debugLineNum = 32;BA.debugLine="Private mt1 As String";
_mt1 = "";
 //BA.debugLineNum = 33;BA.debugLine="Public mt2 As String";
_mt2 = "";
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4j.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _b4xdummy = null;
 //BA.debugLineNum = 49;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 50;BA.debugLine="Log(\"DesignerCreateView==>\")";
__c.LogImpl("2393217","DesignerCreateView==>",0);
 //BA.debugLineNum = 52;BA.debugLine="Log(\"test1\")";
__c.LogImpl("2393219","test1",0);
 //BA.debugLineNum = 53;BA.debugLine="Log(\"Text=\"&Props.Get(\"Text\"))";
__c.LogImpl("2393220","Text="+BA.ObjectToString(_props.Get((Object)("Text"))),0);
 //BA.debugLineNum = 54;BA.debugLine="Log(\"StringExample=\"&Props.Get(\"StringExample\"))";
__c.LogImpl("2393221","StringExample="+BA.ObjectToString(_props.Get((Object)("StringExample"))),0);
 //BA.debugLineNum = 56;BA.debugLine="Private b4xDummy As B4XView";
_b4xdummy = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 59;BA.debugLine="b4xDummy = Base";
_b4xdummy = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 60;BA.debugLine="Log(\"Lbl.Text=\"&Lbl.Text)";
__c.LogImpl("2393227","Lbl.Text="+_lbl.getText(),0);
 //BA.debugLineNum = 61;BA.debugLine="mLeft = b4xDummy.Left";
_mleft = (int) (_b4xdummy.getLeft());
 //BA.debugLineNum = 62;BA.debugLine="mTop = b4xDummy.Top";
_mtop = (int) (_b4xdummy.getTop());
 //BA.debugLineNum = 63;BA.debugLine="mWidth = b4xDummy.Width";
_mwidth = (int) (_b4xdummy.getWidth());
 //BA.debugLineNum = 64;BA.debugLine="mHeight = b4xDummy.Height";
_mheight = (int) (_b4xdummy.getHeight());
 //BA.debugLineNum = 66;BA.debugLine="b4xBase = Base";
_b4xbase = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_base));
 //BA.debugLineNum = 68;BA.debugLine="oButton.Initialize(\"oButton\")	'Button建立";
_obutton.Initialize(ba,"oButton");
 //BA.debugLineNum = 71;BA.debugLine="b4xButton = oButton";
_b4xbutton = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_obutton.getObject()));
 //BA.debugLineNum = 73;BA.debugLine="b4xButton.TextSize = 28";
_b4xbutton.setTextSize(28);
 //BA.debugLineNum = 76;BA.debugLine="b4xButton.Enabled = True";
_b4xbutton.setEnabled(__c.True);
 //BA.debugLineNum = 78;BA.debugLine="If b4xButton.Text = Null Or b4xButton.Text.Length";
if (_b4xbutton.getText()== null || _b4xbutton.getText().length()==0) { 
 //BA.debugLineNum = 79;BA.debugLine="b4xButton.Text = \"按鈕!\"";
_b4xbutton.setText("按鈕!");
 }else {
 //BA.debugLineNum = 82;BA.debugLine="b4xButton.Text = Lbl.Text	'Props.Get(\"Text\")";
_b4xbutton.setText(_lbl.getText());
 //BA.debugLineNum = 83;BA.debugLine="If mt1.Length > 0 Then";
if (_mt1.length()>0) { 
 //BA.debugLineNum = 84;BA.debugLine="b4xButton.Text = mt1";
_b4xbutton.setText(_mt1);
 };
 };
 //BA.debugLineNum = 92;BA.debugLine="b4xBase.AddView(b4xButton, 0, 0, mWidth, mHeight";
_b4xbase.AddView((javafx.scene.Node)(_b4xbutton.getObject()),0,0,_mwidth,_mheight);
 //BA.debugLineNum = 94;BA.debugLine="Log(\"test2\")";
__c.LogImpl("2393261","test2",0);
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public String  _gett1() throws Exception{
 //BA.debugLineNum = 189;BA.debugLine="Public Sub getT1  As String";
 //BA.debugLineNum = 191;BA.debugLine="Return mt1";
if (true) return _mt1;
 //BA.debugLineNum = 192;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 38;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 39;BA.debugLine="Log(\"Initialize==>\")";
__c.LogImpl("2327681","Initialize==>",0);
 //BA.debugLineNum = 41;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 42;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 44;BA.debugLine="mt1 = \"\"";
_mt1 = "";
 //BA.debugLineNum = 45;BA.debugLine="mt2 = \"\"";
_mt2 = "";
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _obutton_click() throws Exception{
 //BA.debugLineNum = 161;BA.debugLine="Private Sub oButton_Click";
 //BA.debugLineNum = 162;BA.debugLine="Log(\"oButton_Click ==>\")";
__c.LogImpl("21507329","oButton_Click ==>",0);
 //BA.debugLineNum = 163;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 164;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _obutton_touch(int _action,double _x,double _y) throws Exception{
 //BA.debugLineNum = 150;BA.debugLine="Private Sub oButton_Touch (Action As Int, X As Dou";
 //BA.debugLineNum = 151;BA.debugLine="Log(\"oButton_Touch==>\")";
__c.LogImpl("21441793","oButton_Touch==>",0);
 //BA.debugLineNum = 152;BA.debugLine="Log( Action)";
__c.LogImpl("21441794",BA.NumberToString(_action),0);
 //BA.debugLineNum = 154;BA.debugLine="If b4xButton.TOUCH_ACTION_UP == Action Then";
if (_b4xbutton.TOUCH_ACTION_UP==_action) { 
 //BA.debugLineNum = 155;BA.debugLine="If SubExists(mCallBack, mEventName & \"_Click\") =";
if (__c.SubExists(ba,_mcallback,_meventname+"_Click")==__c.True) { 
 //BA.debugLineNum = 156;BA.debugLine="CallSub(mCallBack, mEventName & \"_Click\")";
__c.CallSubNew(ba,_mcallback,_meventname+"_Click");
 };
 };
 //BA.debugLineNum = 160;BA.debugLine="End Sub";
return "";
}
public String  _sett1(String _s1) throws Exception{
 //BA.debugLineNum = 179;BA.debugLine="Public Sub setT1(s1 As String)";
 //BA.debugLineNum = 181;BA.debugLine="If s1.Length > 0 Then";
if (_s1.length()>0) { 
 //BA.debugLineNum = 183;BA.debugLine="mt1=s1";
_mt1 = _s1;
 //BA.debugLineNum = 184;BA.debugLine="b4xButton.Text = s1";
_b4xbutton.setText(_s1);
 };
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
